import { useEffect, useRef, useState } from 'react';
import { AudioFX } from './lib/audio';
import { WelcomeScreen } from './components/WelcomeScreen';
import { CameraStage } from './components/CameraStage';

export default function App() {
  const audio = useRef<AudioFX | null>(null);
  if (!audio.current) audio.current = new AudioFX();
  const [phase, setPhase] = useState<'welcome' | 'playing'>('welcome');
  const [session, setSession] = useState(0);

  useEffect(() => () => audio.current?.dispose(), []);

  const start = () => {
    // Called from the button click, so the camera prompt and audio are user-initiated.
    audio.current!.unlock();
    setSession((s) => s + 1);
    setPhase('playing');
  };

  return phase === 'welcome' ? (
    <WelcomeScreen onStart={start} />
  ) : (
    <CameraStage key={session} audio={audio.current} onExit={() => setPhase('welcome')} />
  );
}

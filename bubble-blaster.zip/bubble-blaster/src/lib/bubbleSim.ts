import { FILM_VARIANTS, HL_VARIANTS, PALETTE_RGB } from './constants';

export interface Bubble {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  age: number;
  life: number;
  fadeTime: number;
  alpha: number;
  drag: number;
  rise: number;
  drift: number;
  wobblePhase: number;
  wobbleAmp: number;
  wobbleFreq: number;
  irisPhase: number;
  irisSpeed: number;
  squashPhase: number;
  filmIdx: number;
  hlIdx: number;
  kind: 0 | 1; // 1 = heart-shaped bubble
  tilt: number;
  depth: number;
  dying: boolean;
}

export const P_STAR = 0;
export const P_DROP = 1;
export const P_RING = 2;
export const P_GLOW = 3;

export interface Particle {
  type: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  age: number;
  life: number;
  size: number;
  rot: number;
  rotV: number;
  color: number;
}

/** Bubbles are "blown" at the nozzle: they swell from ~35% to full size. */
export function effRadius(b: Bubble): number {
  const t = Math.min(1, b.age / 0.3);
  const e = 1 - (1 - t) * (1 - t);
  return b.r * (0.35 + 0.65 * e);
}

const TAU = Math.PI * 2;

export class BubbleSim {
  bubbles: Bubble[] = [];
  particles: Particle[] = [];
  maxBubbles = 160;
  maxParticles = 240;
  width = 1;
  height = 1;
  private time = 0;
  private poolB: Bubble[] = [];
  private poolP: Particle[] = [];

  /** Number of bubbles that are not already on their way out. */
  get activeCount(): number {
    let n = 0;
    for (let i = 0; i < this.bubbles.length; i++) if (!this.bubbles[i].dying) n++;
    return n;
  }

  spawn(
    x: number,
    y: number,
    angle: number,
    speed: number,
    r: number,
    inheritVx = 0,
    inheritVy = 0,
  ): Bubble | null {
    // Hard ceiling: bubbles evicted at the soft cap are still fading for ~0.35s.
    if (this.bubbles.length >= Math.ceil(this.maxBubbles * 1.25)) return null;
    if (this.bubbles.length >= this.maxBubbles) this.evictOne();
    const b = this.poolB.pop() ?? this.blank();
    const depth = Math.min(1, r / 70);
    b.x = x;
    b.y = y;
    b.vx = Math.cos(angle) * speed + inheritVx;
    b.vy = Math.sin(angle) * speed + inheritVy;
    b.r = r;
    b.age = 0;
    b.life = 6 + Math.random() * 7 + depth * 2;
    b.fadeTime = Math.min(2.2, b.life * 0.3);
    b.alpha = 0.6 + 0.4 * Math.min(1, r / 30);
    b.drag = 0.9 + Math.random() * 0.8 - depth * 0.25;
    b.rise = 16 + Math.random() * 34 + (1 - depth) * 10;
    b.drift = (Math.random() - 0.5) * 26;
    b.wobblePhase = Math.random() * TAU;
    b.wobbleAmp = 6 + Math.random() * 16;
    b.wobbleFreq = 1.1 + Math.random() * 1.8;
    b.irisPhase = Math.random() * TAU;
    b.irisSpeed = (0.15 + Math.random() * 0.35) * (Math.random() < 0.5 ? -1 : 1);
    b.squashPhase = Math.random() * TAU;
    b.filmIdx = Math.floor(Math.random() * FILM_VARIANTS);
    b.hlIdx = Math.floor(Math.random() * HL_VARIANTS);
    b.kind = r > 14 && Math.random() < 0.03 ? 1 : 0;
    b.tilt = (Math.random() - 0.5) * 0.5;
    b.depth = depth;
    b.dying = false;
    this.insertSorted(b);
    return b;
  }

  private blank(): Bubble {
    return {
      x: 0, y: 0, vx: 0, vy: 0, r: 10, age: 0, life: 8, fadeTime: 1, alpha: 1, drag: 1,
      rise: 20, drift: 0, wobblePhase: 0, wobbleAmp: 10, wobbleFreq: 1, irisPhase: 0,
      irisSpeed: 0.2, squashPhase: 0, filmIdx: 0, hlIdx: 0, kind: 0, tilt: 0, depth: 0,
      dying: false,
    };
  }

  /** Keep the array ordered small -> large so big bubbles draw in front. */
  private insertSorted(b: Bubble) {
    let lo = 0;
    let hi = this.bubbles.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (this.bubbles[mid].r < b.r) lo = mid + 1;
      else hi = mid;
    }
    this.bubbles.splice(lo, 0, b);
  }

  private evictOne() {
    let best = -1;
    let bestRatio = -1;
    for (let i = 0; i < this.bubbles.length; i++) {
      const b = this.bubbles[i];
      if (b.dying) continue;
      const ratio = b.age / b.life;
      if (ratio > bestRatio) {
        bestRatio = ratio;
        best = i;
      }
    }
    if (best >= 0) this.beginDying(this.bubbles[best], 0.35);
  }

  private beginDying(b: Bubble, t: number) {
    b.dying = true;
    b.fadeTime = t;
    b.life = Math.min(b.life, b.age + t);
  }

  private removeBubble(i: number) {
    const [b] = this.bubbles.splice(i, 1);
    if (b) this.poolB.push(b);
  }

  private addParticle(
    type: number, x: number, y: number, vx: number, vy: number,
    life: number, size: number, color: number,
  ) {
    if (this.particles.length >= this.maxParticles) return;
    const p = this.poolP.pop() ?? {
      type: 0, x: 0, y: 0, vx: 0, vy: 0, age: 0, life: 1, size: 1, rot: 0, rotV: 0, color: 0,
    };
    p.type = type;
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.age = 0;
    p.life = life;
    p.size = size;
    p.rot = Math.random() * TAU;
    p.rotV = (Math.random() - 0.5) * 4;
    p.color = color;
    this.particles.push(p);
  }

  private randColor(): number {
    return Math.floor(Math.random() * PALETTE_RGB.length);
  }

  /** Sparkle ring + tiny droplets where a bubble used to be. */
  burst(x: number, y: number, r: number) {
    this.addParticle(P_RING, x, y, 0.55, 0, 0.34, r, this.randColor());
    const n = 6 + Math.min(6, Math.floor(r / 9));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + Math.random() * 0.4;
      const sp = 70 + Math.random() * 110;
      this.addParticle(
        P_STAR,
        x + Math.cos(a) * r * 0.8,
        y + Math.sin(a) * r * 0.8,
        Math.cos(a) * sp,
        Math.sin(a) * sp,
        0.5 + Math.random() * 0.35,
        7 + Math.random() * 8,
        this.randColor(),
      );
    }
    for (let i = 0; i < 5; i++) {
      const a = Math.random() * TAU;
      const sp = 40 + Math.random() * 90;
      this.addParticle(
        P_DROP, x, y, Math.cos(a) * sp, Math.sin(a) * sp - 20,
        0.45 + Math.random() * 0.35, 1.2 + Math.random() * 1.4, this.randColor(),
      );
    }
  }

  /** Little luminous ring + glow at a gun nozzle. */
  muzzleFlash(x: number, y: number) {
    this.addParticle(P_RING, x, y, 2.2, 0, 0.32, 9, this.randColor());
    this.addParticle(P_GLOW, x, y, 0, 0, 0.24, 26, 0);
  }

  /** Pops bubble at index i, returns its visible radius. */
  pop(i: number): number {
    const b = this.bubbles[i];
    const r = effRadius(b);
    this.burst(b.x, b.y, r);
    this.removeBubble(i);
    return r;
  }

  /** Front-most bubble under (x, y), or -1. */
  pickAt(x: number, y: number): number {
    for (let i = this.bubbles.length - 1; i >= 0; i--) {
      const b = this.bubbles[i];
      const r = effRadius(b) + 4;
      const dx = x - b.x;
      const dy = y - b.y;
      if (dx * dx + dy * dy <= r * r) return i;
    }
    return -1;
  }

  /** Pops the first old-enough bubble touching a point. Returns popped radius or 0. */
  popNear(x: number, y: number, pad: number, minAge: number): number {
    for (let i = this.bubbles.length - 1; i >= 0; i--) {
      const b = this.bubbles[i];
      if (b.age < minAge) continue;
      const r = effRadius(b) * 0.85 + pad;
      const dx = x - b.x;
      const dy = y - b.y;
      if (dx * dx + dy * dy <= r * r) return this.pop(i);
    }
    return 0;
  }

  /** Fades everything out smoothly. */
  clear() {
    for (const b of this.bubbles) this.beginDying(b, 0.35);
    for (const p of this.particles) p.life = Math.min(p.life, p.age + 0.2);
  }

  /** Hard reset used on shutdown. */
  reset() {
    while (this.bubbles.length) this.removeBubble(this.bubbles.length - 1);
    while (this.particles.length) this.poolP.push(this.particles.pop()!);
  }

  step(dt: number) {
    this.time += dt;
    const t = this.time;
    const w = this.width;

    for (let i = this.bubbles.length - 1; i >= 0; i--) {
      const b = this.bubbles[i];
      b.age += dt;
      if (b.age >= b.life) {
        // A few bubbles pop with a tiny sparkle instead of just fading.
        if (!b.dying && Math.random() < 0.3) this.burst(b.x, b.y, effRadius(b) * 0.8);
        this.removeBubble(i);
        continue;
      }
      // Gentle air currents that vary smoothly in space and time.
      const air = 1 - 0.4 * b.depth;
      const wx = (14 * Math.sin(t * 0.35 + b.y * 0.006) + 8 * Math.sin(t * 0.9 + b.y * 0.013 + 1.7)) * air;
      const wy = 4 * Math.sin(t * 0.5 + b.x * 0.004);
      const k = 1 - Math.exp(-b.drag * dt);
      b.vx += (b.drift + wx - b.vx) * k;
      b.vy += (-b.rise + wy - b.vy) * k;
      b.wobblePhase += b.wobbleFreq * dt;
      b.irisPhase += b.irisSpeed * dt;
      b.x += (b.vx + Math.cos(b.wobblePhase) * b.wobbleAmp) * dt;
      b.y += (b.vy + Math.sin(b.wobblePhase * 0.8) * b.wobbleAmp * 0.35) * dt;
      if (b.y < -b.r * 2 || b.x < -b.r * 2.5 || b.x > w + b.r * 2.5) this.removeBubble(i);
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;
      if (p.age >= p.life) {
        this.poolP.push(p);
        this.particles.splice(i, 1);
        continue;
      }
      if (p.type === P_STAR || p.type === P_DROP) {
        if (p.type === P_DROP) p.vy += 140 * dt;
        const damp = Math.exp(-2.4 * dt);
        p.vx *= damp;
        p.vy *= damp;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.rotV * dt;
      }
    }
  }
}

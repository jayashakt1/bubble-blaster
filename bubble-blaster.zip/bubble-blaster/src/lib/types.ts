export interface Vec {
  x: number;
  y: number;
}

export type Side = 'left' | 'right';
export type TrackingState = 'idle' | 'loading' | 'ready' | 'error';

export interface StatusSnapshot {
  camera: boolean;
  left: boolean;
  right: boolean;
  leftFiring: boolean;
  rightFiring: boolean;
  bubbles: number;
  tracking: TrackingState;
  firedOnce: boolean;
}

export const INITIAL_STATUS: StatusSnapshot = {
  camera: false,
  left: false,
  right: false,
  leftFiring: false,
  rightFiring: false,
  bubbles: 0,
  tracking: 'idle',
  firedOnce: false,
};

export class GameError extends Error {
  kind: 'camera' | 'model';
  /** True when the failure was only caused by the experience being closed. */
  cancelled: boolean;
  constructor(kind: 'camera' | 'model', message: string, cancelled = false) {
    super(message);
    this.kind = kind;
    this.cancelled = cancelled;
  }
}

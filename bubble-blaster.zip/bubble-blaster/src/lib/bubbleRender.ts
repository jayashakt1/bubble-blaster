import { FILM_VARIANTS, HL_VARIANTS, PALETTE_RGB } from './constants';
import { BubbleSim, effRadius, P_DROP, P_GLOW, P_RING, P_STAR } from './bubbleSim';

const TAU = Math.PI * 2;
const SPRITE = 256;
const RGB = PALETTE_RGB.map((c) => `rgb(${c})`);

function rng(seed: number) {
  let s = (Math.imul(seed + 1, 2654435761) >>> 0) || 1;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function makeCanvas(size: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  return c;
}

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.lineTo(x + w - r, y);
  g.quadraticCurveTo(x + w, y, x + w, y + r);
  g.lineTo(x + w, y + h - r);
  g.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  g.lineTo(x + r, y + h);
  g.quadraticCurveTo(x, y + h, x, y + h - r);
  g.lineTo(x, y + r);
  g.quadraticCurveTo(x, y, x + r, y);
  g.closePath();
}

function shapePath(g: CanvasRenderingContext2D, c: number, R: number, heart: boolean) {
  g.beginPath();
  if (heart) {
    g.moveTo(c, c + 0.86 * R);
    g.bezierCurveTo(c - 1.15 * R, c + 0.05 * R, c - 0.9 * R, c - 0.95 * R, c, c - 0.38 * R);
    g.bezierCurveTo(c + 0.9 * R, c - 0.95 * R, c + 1.15 * R, c + 0.05 * R, c, c + 0.86 * R);
    g.closePath();
  } else {
    g.arc(c, c, R, 0, TAU);
  }
}

/**
 * Iridescent soap film: a nearly transparent centre, a swirl of pastel colour that
 * grows toward the rim, and a thin coloured edge. Rotating this layer at draw time
 * makes the colours shimmer while the highlight layer stays put.
 */
function makeFilm(seed: number, heart: boolean): HTMLCanvasElement {
  const size = SPRITE;
  const c = size / 2;
  const R = size * 0.47;
  const rand = rng(seed);
  const cv = makeCanvas(size);
  const g = cv.getContext('2d')!;

  const field = makeCanvas(size);
  const f = field.getContext('2d')!;
  const hues = [330, 300, 265, 215, 185, 160, 55, 25];

  f.save();
  shapePath(f, c, R, heart);
  f.clip();

  const conic = (f as unknown as {
    createConicGradient?: (a: number, x: number, y: number) => CanvasGradient;
  }).createConicGradient;
  if (typeof conic === 'function') {
    const cg = conic.call(f, rand() * TAU, c, c);
    const n = 8;
    const start = Math.floor(rand() * hues.length);
    const cols: string[] = [];
    for (let i = 0; i < n; i++) cols.push(`hsla(${hues[(start + i * 3) % hues.length]},85%,80%,0.55)`);
    for (let i = 0; i < n; i++) cg.addColorStop(i / n, cols[i]);
    cg.addColorStop(1, cols[0]);
    f.fillStyle = cg;
    f.fillRect(0, 0, size, size);
  }
  for (let k = 0; k < 10; k++) {
    const bx = c + (rand() - 0.5) * R * 1.5;
    const by = c + (rand() - 0.5) * R * 1.5;
    const br = R * (0.22 + rand() * 0.45);
    const h = hues[Math.floor(rand() * hues.length)];
    const rg = f.createRadialGradient(bx, by, 0, bx, by, br);
    rg.addColorStop(0, `hsla(${h},95%,80%,0.42)`);
    rg.addColorStop(1, `hsla(${h},95%,80%,0)`);
    f.fillStyle = rg;
    f.fillRect(0, 0, size, size);
  }
  f.restore();

  // Keep the colour mostly near the rim so the centre stays see-through.
  f.globalCompositeOperation = 'destination-in';
  const m = f.createRadialGradient(c, c, R * 0.15, c, c, R);
  m.addColorStop(0, 'rgba(0,0,0,0)');
  m.addColorStop(0.55, 'rgba(0,0,0,0.18)');
  m.addColorStop(0.85, 'rgba(0,0,0,0.55)');
  m.addColorStop(0.97, 'rgba(0,0,0,0.9)');
  m.addColorStop(1, 'rgba(0,0,0,0)');
  f.fillStyle = m;
  f.fillRect(0, 0, size, size);

  g.drawImage(field, 0, 0);

  // faint pearly body
  shapePath(g, c, R, heart);
  g.fillStyle = 'rgba(255,255,255,0.035)';
  g.fill();

  // coloured rim
  const rim = g.createLinearGradient(c - R, c - R, c + R, c + R);
  rim.addColorStop(0, 'rgba(255,190,220,0.65)');
  rim.addColorStop(0.35, 'rgba(190,230,255,0.55)');
  rim.addColorStop(0.65, 'rgba(255,245,190,0.5)');
  rim.addColorStop(1, 'rgba(215,190,255,0.6)');
  shapePath(g, c, R * 0.975, heart);
  g.strokeStyle = rim;
  g.lineWidth = size * 0.014;
  g.stroke();

  // whisper-thin outline so bubbles stay visible on bright rooms
  shapePath(g, c, R, heart);
  g.strokeStyle = 'rgba(150,100,170,0.16)';
  g.lineWidth = size * 0.008;
  g.stroke();
  return cv;
}

/** Specular layer: window reflections, curved sheen, glints. Never rotated. */
function makeHighlight(variant: number, heart: boolean): HTMLCanvasElement {
  const size = SPRITE;
  const c = size / 2;
  const R = size * 0.47 * (heart ? 0.82 : 1);
  const cv = makeCanvas(size);
  const g = cv.getContext('2d')!;

  const sh = g.createRadialGradient(c - R * 0.4, c - R * 0.45, 0, c - R * 0.4, c - R * 0.45, R * 0.9);
  sh.addColorStop(0, 'rgba(255,255,255,0.28)');
  sh.addColorStop(1, 'rgba(255,255,255,0)');
  shapePath(g, c, size * 0.47, heart);
  g.fillStyle = sh;
  g.fill();

  g.lineCap = 'round';
  g.strokeStyle = 'rgba(255,255,255,0.92)';
  g.lineWidth = size * 0.045;
  g.beginPath();
  g.arc(c, c, R * 0.8, Math.PI * 1.08, Math.PI * 1.42);
  g.stroke();
  g.strokeStyle = 'rgba(255,255,255,0.7)';
  g.lineWidth = size * 0.02;
  g.beginPath();
  g.arc(c, c, R * 0.8, Math.PI * 1.46, Math.PI * 1.56);
  g.stroke();
  g.strokeStyle = 'rgba(210,240,255,0.5)';
  g.lineWidth = size * 0.03;
  g.beginPath();
  g.arc(c, c, R * 0.82, Math.PI * 0.12, Math.PI * 0.38);
  g.stroke();

  if (!heart) {
    for (const ang of [Math.PI * 0.99, 0]) {
      g.save();
      g.translate(c, c);
      g.rotate(ang);
      rr(g, R * 0.8, -size * 0.05, size * 0.05, size * 0.1, size * 0.02);
      g.fillStyle = `rgba(255,255,255,${variant % 2 ? 0.75 : 0.5})`;
      g.fill();
      g.restore();
    }
  }

  const gx = c - R * 0.46;
  const gy = c - R * 0.52;
  const gl = g.createRadialGradient(gx, gy, 0, gx, gy, R * 0.12);
  gl.addColorStop(0, 'rgba(255,255,255,0.95)');
  gl.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gl;
  g.fillRect(gx - R * 0.12, gy - R * 0.12, R * 0.24, R * 0.24);

  if (variant % 2 === 0) {
    // little starburst glint, like the sparkles in the reference photos
    const sx = c + R * 0.28;
    const sy = c + R * 0.2;
    const sr = R * 0.22;
    const sg = g.createRadialGradient(sx, sy, 0, sx, sy, sr);
    sg.addColorStop(0, 'rgba(255,255,255,0.9)');
    sg.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = sg;
    g.fillRect(sx - sr, sy - sr, sr * 2, sr * 2);
    g.fillStyle = 'rgba(255,255,255,0.9)';
    g.beginPath();
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4 - Math.PI / 2;
      const rad = i % 2 === 0 ? sr : sr * 0.14;
      const px = sx + Math.cos(a) * rad;
      const py = sy + Math.sin(a) * rad;
      if (i === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.closePath();
    g.fill();
  }
  return cv;
}

function makeStar(rgb: string): HTMLCanvasElement {
  const size = 64;
  const c = size / 2;
  const cv = makeCanvas(size);
  const g = cv.getContext('2d')!;
  const glow = g.createRadialGradient(c, c, 0, c, c, c);
  glow.addColorStop(0, `rgba(${rgb},0.55)`);
  glow.addColorStop(1, `rgba(${rgb},0)`);
  g.fillStyle = glow;
  g.fillRect(0, 0, size, size);
  g.beginPath();
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4 - Math.PI / 2;
    const rad = i % 2 === 0 ? c * 0.92 : c * 0.16;
    const px = c + Math.cos(a) * rad;
    const py = c + Math.sin(a) * rad;
    if (i === 0) g.moveTo(px, py);
    else g.lineTo(px, py);
  }
  g.closePath();
  g.fillStyle = 'rgba(255,255,255,0.95)';
  g.fill();
  return cv;
}

function makeGlow(): HTMLCanvasElement {
  const size = 96;
  const c = size / 2;
  const cv = makeCanvas(size);
  const g = cv.getContext('2d')!;
  const rg = g.createRadialGradient(c, c, 0, c, c, c);
  rg.addColorStop(0, 'rgba(255,255,255,0.9)');
  rg.addColorStop(0.4, 'rgba(255,200,230,0.45)');
  rg.addColorStop(1, 'rgba(255,200,230,0)');
  g.fillStyle = rg;
  g.fillRect(0, 0, size, size);
  return cv;
}

export class BubbleRenderer {
  private ctx: CanvasRenderingContext2D;
  private dpr = 1;
  private film: HTMLCanvasElement[] = [];
  private hl: HTMLCanvasElement[] = [];
  private heartFilm: HTMLCanvasElement;
  private heartHl: HTMLCanvasElement;
  private stars: HTMLCanvasElement[];
  private glow: HTMLCanvasElement;

  constructor(private canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('2D canvas is not available in this browser.');
    this.ctx = ctx;
    for (let i = 0; i < FILM_VARIANTS; i++) this.film.push(makeFilm(i * 7 + 3, false));
    for (let i = 0; i < HL_VARIANTS; i++) this.hl.push(makeHighlight(i, false));
    this.heartFilm = makeFilm(99, true);
    this.heartHl = makeHighlight(1, true);
    this.stars = PALETTE_RGB.map(makeStar);
    this.glow = makeGlow();
  }

  resize(w: number, h: number, dpr: number) {
    this.dpr = dpr;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
  }

  draw(sim: BubbleSim) {
    const ctx = this.ctx;
    const dpr = this.dpr;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    const bubbles = sim.bubbles;
    for (let i = 0; i < bubbles.length; i++) {
      const b = bubbles[i];
      const fadeIn = Math.min(1, b.age / 0.18);
      const fadeOut = Math.min(1, (b.life - b.age) / b.fadeTime);
      const a = b.alpha * fadeIn * fadeOut;
      if (a <= 0.01) continue;
      const r = effRadius(b);
      const sq = 0.045 * Math.sin(b.wobblePhase * 1.3 + b.squashPhase);
      const sx = 1 + sq;
      const sy = 1 - sq;
      const heart = b.kind === 1;
      const rot = heart ? b.tilt : b.irisPhase;
      const c = Math.cos(rot);
      const s = Math.sin(rot);

      ctx.globalAlpha = a * 0.95;
      ctx.setTransform(dpr * c * sx, dpr * s * sx, -dpr * s * sy, dpr * c * sy, dpr * b.x, dpr * b.y);
      ctx.drawImage(heart ? this.heartFilm : this.film[b.filmIdx], -r, -r, r * 2, r * 2);

      ctx.globalAlpha = a * (0.55 + 0.45 * Math.min(1, r / 40));
      ctx.setTransform(dpr * sx, 0, 0, dpr * sy, dpr * b.x, dpr * b.y);
      ctx.drawImage(heart ? this.heartHl : this.hl[b.hlIdx], -r, -r, r * 2, r * 2);
    }

    ctx.globalCompositeOperation = 'lighter';
    const parts = sim.particles;
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      const t = p.age / p.life;
      const a = 1 - t;
      switch (p.type) {
        case P_STAR: {
          const s = p.size * (1 - 0.35 * t);
          const cs = Math.cos(p.rot);
          const sn = Math.sin(p.rot);
          ctx.globalAlpha = Math.min(1, a * 1.6) * (0.75 + 0.25 * Math.sin(p.age * 30 + p.rot));
          ctx.setTransform(dpr * cs, dpr * sn, -dpr * sn, dpr * cs, dpr * p.x, dpr * p.y);
          ctx.drawImage(this.stars[p.color % this.stars.length], -s, -s, s * 2, s * 2);
          break;
        }
        case P_DROP:
          ctx.globalAlpha = a * 0.8;
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          ctx.fillStyle = RGB[p.color % RGB.length];
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, TAU);
          ctx.fill();
          break;
        case P_RING: {
          const grow = p.vx > 0 ? p.vx : 0.55;
          ctx.globalAlpha = a * 0.9;
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          ctx.strokeStyle = RGB[p.color % RGB.length];
          ctx.lineWidth = 2 * (1 - t) + 0.5;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (1 + t * grow) + 2, 0, TAU);
          ctx.stroke();
          break;
        }
        case P_GLOW: {
          const s = p.size * (0.7 + t * 0.8);
          ctx.globalAlpha = a * 0.9;
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          ctx.drawImage(this.glow, p.x - s, p.y - s, s * 2, s * 2);
          break;
        }
        default:
          break;
      }
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.setTransform(1, 0, 0, 1, 0, 0);
  }
}

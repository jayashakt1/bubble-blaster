import { BubbleSim } from './bubbleSim';
import { BubbleRenderer } from './bubbleRender';
import { HandTrackingService, RawHand } from './HandTrackingService';
import {
  ViewMap,
  HandPose,
  computeHandPose,
  createPoints,
  createPose,
  makeViewMap,
} from './handMapping';
import { TriggerState } from './gestures';
import { GUN_MUZZLE, GUN_PIVOT, GUN_W } from './constants';
import type { AudioFX } from './audio';
import { GameError, Side, StatusSnapshot, TrackingState, Vec } from './types';

const TAU = Math.PI * 2;
const PRESENT_MS = 220; // a hand counts as "there" this long after its last detection
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
function wrapPi(a: number) {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
}

/**
 * MediaPipe assumes selfie-mirrored input when it labels hands. We feed it the raw
 * (un-mirrored) frame, so its "Left" is the user's right hand. Press "H" in the
 * app to swap if a browser/model build ever reports the opposite.
 */
const FLIP_HANDEDNESS = true;

interface GunState {
  side: Side;
  el: HTMLElement;
  x: number; y: number; angle: number; scale: number; flip: number; flipTarget: number;
  tx: number; ty: number; tAngle: number; tScale: number;
  vx: number; vy: number;
  opacity: number;
  lastSeen: number;
  present: boolean;
  init: boolean;
  trig: TriggerState;
  firing: boolean;
  effFiring: boolean;
  wasFiring: boolean;
  acc: number;
  recoil: number;
  mx: number; my: number;
  tip: Vec;
  popCool: number;
  domFiring: boolean;
  domVisible: boolean;
}

function makeGun(side: Side, el: HTMLElement): GunState {
  return {
    side, el,
    x: 0, y: 0, angle: 0, scale: 1, flip: 1, flipTarget: 1,
    tx: 0, ty: 0, tAngle: 0, tScale: 1,
    vx: 0, vy: 0, opacity: 0, lastSeen: -Infinity, present: false, init: false,
    trig: new TriggerState(), firing: false, effFiring: false, wasFiring: false,
    acc: 0, recoil: 0, mx: 0, my: 0, tip: { x: 0, y: 0 }, popCool: 0,
    domFiring: false, domVisible: false,
  };
}

export interface EngineOpts {
  stage: HTMLElement;
  video: HTMLVideoElement;
  canvas: HTMLCanvasElement;
  leftGun: HTMLElement;
  rightGun: HTMLElement;
  audio: AudioFX;
  onStatus: (s: StatusSnapshot) => void;
}

function cameraMessage(e: unknown): string {
  const name = (e as { name?: string } | null)?.name;
  switch (name) {
    case 'NotAllowedError':
    case 'SecurityError':
      return 'Camera permission was blocked. Please allow camera access for this page (look for the camera icon in your address bar) and try again ♡';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'No camera was found on this device. Plug one in or switch to a device with a webcam, then try again ♡';
    case 'NotReadableError':
    case 'TrackStartError':
    case 'AbortError':
      return 'Your camera seems to be in use by another app or tab. Close it and try again ♡';
    default:
      return 'The camera could not be started. Please check your browser settings and try again ♡';
  }
}

export class GameEngine {
  paused = false;
  shower = false;

  private o: EngineOpts;
  private sim = new BubbleSim();
  private renderer: BubbleRenderer;
  private tracker = new HandTrackingService();
  private stream: MediaStream | null = null;
  private tracking: TrackingState = 'idle';
  private disposed = false;
  private raf = 0;
  private looping = false;

  private last = 0;
  private lastDetect = 0;
  private lastVideoTime = -1;
  private detectInterval = 33;
  private inferAvg = 12;
  private detectErrors = 0;

  private stageW = 1;
  private stageH = 1;
  private dpr = 1;
  private view: ViewMap | null = null;

  private guns: Record<Side, GunState>;
  private pts = [createPoints(), createPoints()];
  private poses: HandPose[] = [createPose(), createPose()];
  private swapped = false;

  private firedOnce = false;
  private lastStatus = 0;
  private prevKey = '';
  private frameAvg = 16;
  private frameCount = 0;
  private qualityRate = 1;
  private baseMaxBubbles: number;
  private baseMaxParticles: number;

  private reduced: boolean;
  private isMobile: boolean;
  private ro: ResizeObserver | null = null;

  constructor(opts: EngineOpts) {
    this.o = opts;
    this.renderer = new BubbleRenderer(opts.canvas);
    this.guns = { left: makeGun('left', opts.leftGun), right: makeGun('right', opts.rightGun) };
    this.reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    this.isMobile =
      (window.matchMedia?.('(max-width: 700px)').matches ?? false) || /Mobi|Android/i.test(navigator.userAgent);
    this.baseMaxBubbles = this.isMobile ? 90 : 160;
    this.baseMaxParticles = this.isMobile ? 140 : 240;
    this.sim.maxBubbles = this.baseMaxBubbles;
    this.sim.maxParticles = this.baseMaxParticles;

    this.ro = new ResizeObserver(() => this.updateView());
    this.ro.observe(opts.stage);
    opts.video.addEventListener('loadedmetadata', this.updateView);
    opts.video.addEventListener('resize', this.updateView);
    opts.canvas.addEventListener('pointerdown', this.onPointer);
    this.updateView();
  }

  // ---------------------------------------------------------------- lifecycle

  async startCamera(): Promise<void> {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new GameError(
        'camera',
        window.isSecureContext
          ? 'This browser does not support camera access. Please try a recent version of Chrome, Edge, Safari or Firefox ♡'
          : 'Camera access needs a secure connection (HTTPS or localhost). Please open the site over HTTPS ♡',
      );
    }
    let stream: MediaStream;
    try {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
      } catch (e) {
        if ((e as { name?: string })?.name === 'OverconstrainedError') {
          stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        } else {
          throw e;
        }
      }
    } catch (e) {
      throw new GameError('camera', cameraMessage(e));
    }
    if (this.disposed) {
      stream.getTracks().forEach((t) => t.stop());
      throw new GameError('camera', 'cancelled', true);
    }
    this.stream = stream;
    const v = this.o.video;
    v.muted = true;
    v.playsInline = true;
    v.srcObject = stream;
    await new Promise<void>((resolve) => {
      if (v.readyState >= 1) resolve();
      else v.addEventListener('loadedmetadata', () => resolve(), { once: true });
    });
    try {
      await v.play();
    } catch {
      /* muted autoplay is allowed; ignore transient play() rejections */
    }
    if (this.disposed) throw new GameError('camera', 'cancelled', true);
    this.updateView();
  }

  async initTracker(): Promise<void> {
    this.tracking = 'loading';
    this.detectErrors = 0;
    try {
      await this.tracker.init();
    } catch {
      this.tracking = 'error';
      throw new GameError(
        'model',
        'The hand-tracking model could not be loaded. It is downloaded once from the internet, so please check your connection and try again ♡',
      );
    }
    if (this.disposed) {
      this.tracker.dispose();
      throw new GameError('model', 'cancelled', true);
    }
    this.tracking = 'ready';
  }

  startLoop() {
    if (this.looping || this.disposed) return;
    this.looping = true;
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.tick);
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.looping = false;
    cancelAnimationFrame(this.raf);
    this.ro?.disconnect();
    this.o.video.removeEventListener('loadedmetadata', this.updateView);
    this.o.video.removeEventListener('resize', this.updateView);
    this.o.canvas.removeEventListener('pointerdown', this.onPointer);
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    this.o.video.pause();
    this.o.video.srcObject = null;
    this.tracker.dispose();
    this.sim.reset();
    (['left', 'right'] as Side[]).forEach((s) => {
      this.guns[s].el.style.visibility = 'hidden';
    });
  }

  // ---------------------------------------------------------------- controls

  setPaused(p: boolean) {
    this.paused = p;
  }
  setShower(on: boolean) {
    this.shower = on;
  }
  clear() {
    this.sim.clear();
  }
  swapHands() {
    this.swapped = !this.swapped;
  }

  // ---------------------------------------------------------------- view

  private updateView = () => {
    const { stage, video } = this.o;
    const w = stage.clientWidth;
    const h = stage.clientHeight;
    if (!w || !h) return;
    this.stageW = w;
    this.stageH = h;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.renderer.resize(w, h, this.dpr);
    this.sim.width = w;
    this.sim.height = h;
    this.view = makeViewMap(w, h, video.videoWidth || w, video.videoHeight || h, true);
  };

  private onPointer = (e: PointerEvent) => {
    const rect = this.o.canvas.getBoundingClientRect();
    const idx = this.sim.pickAt(e.clientX - rect.left, e.clientY - rect.top);
    if (idx >= 0) {
      const r = this.sim.pop(idx);
      this.o.audio.pop(r);
    }
  };

  // ---------------------------------------------------------------- main loop

  private tick = (now: number) => {
    if (!this.looping) return;
    this.raf = requestAnimationFrame(this.tick);
    const dt = Math.min(0.05, Math.max(0.001, (now - this.last) / 1000));
    this.last = now;

    this.adaptQuality(dt);
    this.detect(now);
    this.updateGuns(now, dt);
    if (!this.paused) {
      this.fire(dt);
      this.handPop(dt);
      this.sim.step(dt);
    }
    this.renderer.draw(this.sim);
    this.emitStatus(now);
  };

  private adaptQuality(dt: number) {
    this.frameAvg = this.frameAvg * 0.95 + dt * 1000 * 0.05;
    if (++this.frameCount % 90 !== 0) return;
    if (this.frameAvg > 27 && this.sim.maxBubbles > 50) {
      this.sim.maxBubbles = Math.max(50, Math.floor(this.sim.maxBubbles * 0.8));
      this.sim.maxParticles = Math.max(80, Math.floor(this.sim.maxParticles * 0.85));
      this.qualityRate = Math.max(0.5, this.qualityRate * 0.85);
    } else if (this.frameAvg < 18 && this.sim.maxBubbles < this.baseMaxBubbles) {
      this.sim.maxBubbles = Math.min(this.baseMaxBubbles, Math.ceil(this.sim.maxBubbles * 1.1));
      this.sim.maxParticles = Math.min(this.baseMaxParticles, Math.ceil(this.sim.maxParticles * 1.1));
      this.qualityRate = Math.min(1, this.qualityRate * 1.05);
    }
  }

  // ---------------------------------------------------------------- tracking

  private detect(now: number) {
    if (this.tracking !== 'ready' || !this.view) return;
    const v = this.o.video;
    if (v.readyState < 2 || v.videoWidth === 0) return;
    if (v.currentTime === this.lastVideoTime) return;
    if (now - this.lastDetect < this.detectInterval) return;
    this.lastVideoTime = v.currentTime;
    const dtMs = Math.min(120, now - this.lastDetect);
    this.lastDetect = now;

    const t0 = performance.now();
    let hands: RawHand[] | null = null;
    try {
      hands = this.tracker.detect(v, now);
      this.detectErrors = 0;
    } catch {
      if (++this.detectErrors > 30) this.tracking = 'error';
      return;
    }
    this.inferAvg = this.inferAvg * 0.9 + (performance.now() - t0) * 0.1;
    this.detectInterval = clamp(this.inferAvg * 1.1, 16, 45);
    if (hands) this.assign(hands, now, dtMs);
  }

  private assign(hands: RawHand[], now: number, dtMs: number) {
    const view = this.view!;
    const n = Math.min(2, hands.length);
    const sides: Side[] = [];
    for (let i = 0; i < n; i++) {
      computeHandPose(hands[i].landmarks, view, this.pts[i], this.poses[i]);
      let isLeft = hands[i].label === 'Left';
      if (FLIP_HANDEDNESS) isLeft = !isLeft;
      if (this.swapped) isLeft = !isLeft;
      sides.push(isLeft ? 'left' : 'right');
    }
    if (n === 2 && sides[0] === sides[1]) {
      // Same label twice: fall back to where the hands are on screen.
      const firstIsLeft = this.poses[0].palm.x <= this.poses[1].palm.x;
      sides[0] = firstIsLeft ? 'left' : 'right';
      sides[1] = firstIsLeft ? 'right' : 'left';
    }
    for (let i = 0; i < n; i++) this.applyPose(this.guns[sides[i]], this.poses[i], now, dtMs);
  }

  private applyPose(g: GunState, pose: HandPose, now: number, dtMs: number) {
    g.tx = clamp(pose.palm.x, 0, this.stageW);
    g.ty = clamp(pose.palm.y, 0, this.stageH);
    g.tAngle = pose.angle;
    g.tScale = clamp((pose.size * 3.3) / GUN_W, 0.45, 1.6);
    g.tip.x = pose.indexTip.x;
    g.tip.y = pose.indexTip.y;
    g.lastSeen = now;
    g.trig.update(pose.pinch, dtMs);
    g.firing = g.trig.active;
  }

  // ---------------------------------------------------------------- guns

  private updateGuns(now: number, dt: number) {
    (['left', 'right'] as Side[]).forEach((side) => {
      const g = this.guns[side];
      g.present = now - g.lastSeen < PRESENT_MS;
      if (g.present) {
        g.opacity = Math.min(1, g.opacity + dt * 7);
      } else {
        g.opacity = Math.max(0, g.opacity - dt * 2.2);
        g.firing = false;
        g.trig.reset();
      }
      g.effFiring = g.present && (g.firing || this.shower);

      if (g.opacity <= 0.001) {
        if (g.domVisible) {
          g.el.style.visibility = 'hidden';
          g.domVisible = false;
        }
        g.init = false;
        g.vx = 0;
        g.vy = 0;
        return;
      }

      if (g.present) {
        if (!g.init) {
          g.x = g.tx; g.y = g.ty; g.angle = g.tAngle; g.scale = g.tScale;
          g.flipTarget = Math.cos(g.tAngle) < 0 ? -1 : 1;
          g.flip = g.flipTarget;
          g.init = true;
        } else {
          const px = g.x;
          const py = g.y;
          const aPos = 1 - Math.exp(-dt * 22);
          g.x += (g.tx - g.x) * aPos;
          g.y += (g.ty - g.y) * aPos;
          g.angle += wrapPi(g.tAngle - g.angle) * (1 - Math.exp(-dt * 14));
          g.scale += (g.tScale - g.scale) * (1 - Math.exp(-dt * 8));
          const c = Math.cos(g.angle);
          if (c < -0.15) g.flipTarget = -1;
          else if (c > 0.15) g.flipTarget = 1;
          g.vx = g.vx * 0.8 + ((g.x - px) / dt) * 0.2;
          g.vy = g.vy * 0.8 + ((g.y - py) / dt) * 0.2;
        }
      }
      g.flip += (g.flipTarget - g.flip) * (1 - Math.exp(-dt * 16));
      g.recoil *= Math.exp(-dt * 12);

      const cos = Math.cos(g.angle);
      const sin = Math.sin(g.angle);
      const rx = g.x - cos * g.recoil * 14 * g.scale;
      const ry = g.y - sin * g.recoil * 14 * g.scale;

      // Same maths as the CSS transform below: pivot -> scale -> rotate -> translate.
      const lx = (GUN_MUZZLE.x - GUN_PIVOT.x) * g.scale;
      const ly = (GUN_MUZZLE.y - GUN_PIVOT.y) * g.scale * g.flip;
      g.mx = rx + cos * lx - sin * ly;
      g.my = ry + sin * lx + cos * ly;

      const el = g.el;
      el.style.transform =
        `translate3d(${rx.toFixed(1)}px,${ry.toFixed(1)}px,0) rotate(${g.angle.toFixed(4)}rad) ` +
        `scale(${g.scale.toFixed(3)},${(g.scale * g.flip).toFixed(3)}) ` +
        `translate(${-GUN_PIVOT.x}px,${-GUN_PIVOT.y}px)`;
      el.style.opacity = g.opacity.toFixed(3);
      if (!g.domVisible) {
        el.style.visibility = 'visible';
        g.domVisible = true;
      }
      if (g.domFiring !== g.effFiring) {
        el.dataset.firing = g.effFiring ? '1' : '0';
        g.domFiring = g.effFiring;
      }
    });
  }

  // ---------------------------------------------------------------- firing

  private fire(dt: number) {
    (['left', 'right'] as Side[]).forEach((side) => {
      const g = this.guns[side];
      if (!g.effFiring || g.opacity < 0.5) {
        g.wasFiring = false;
        g.acc = 0;
        return;
      }
      const rate =
        (g.firing && this.shower ? 26 : this.shower ? 22 : 9) * (this.reduced ? 0.6 : 1) * this.qualityRate;
      if (!g.wasFiring) {
        g.wasFiring = true;
        for (let i = 0; i < 7; i++) this.emit(g, true);
        this.sim.muzzleFlash(g.mx, g.my);
        g.recoil = 1;
        this.firedOnce = true;
        this.o.audio.fire();
        g.acc = 0.3;
        return;
      }
      g.acc += dt * rate;
      while (g.acc >= 1) {
        g.acc -= 1;
        this.emit(g, false);
        g.recoil = Math.min(1, g.recoil + 0.35);
        this.sim.muzzleFlash(g.mx, g.my);
        this.o.audio.fire();
      }
    });
  }

  private emit(g: GunState, burst: boolean) {
    const roll = Math.random();
    let r = burst
      ? 5 + Math.random() * 9
      : roll < 0.62
        ? 7 + Math.random() * 10
        : roll < 0.92
          ? 17 + Math.random() * 18
          : 36 + Math.random() * 40;
    if (this.isMobile) r *= 0.8;
    const spread = burst ? 0.7 : 0.32;
    const ang = g.angle + (Math.random() - 0.5) * spread;
    const speed = (200 + Math.random() * 330) * (1 - Math.min(0.55, r / 140));
    const jitter = (Math.random() - 0.5) * 8;
    const nx = -Math.sin(g.angle);
    const ny = Math.cos(g.angle);
    this.sim.spawn(g.mx + nx * jitter, g.my + ny * jitter, ang, speed, r, g.vx * 0.25, g.vy * 0.25);
  }

  /** Index fingertip pops bubbles it touches (only when that hand is not firing). */
  private handPop(dt: number) {
    (['left', 'right'] as Side[]).forEach((side) => {
      const g = this.guns[side];
      g.popCool = Math.max(0, g.popCool - dt);
      if (!g.present || g.effFiring || g.popCool > 0) return;
      const r = this.sim.popNear(g.tip.x, g.tip.y, 10, 0.8);
      if (r > 0) {
        g.popCool = 0.12;
        this.o.audio.pop(r);
      }
    });
  }

  // ---------------------------------------------------------------- status

  private emitStatus(now: number) {
    if (now - this.lastStatus < 100) return;
    this.lastStatus = now;
    const s: StatusSnapshot = {
      camera: !!this.stream && this.stream.getVideoTracks().some((t) => t.readyState === 'live'),
      left: this.guns.left.present,
      right: this.guns.right.present,
      leftFiring: this.guns.left.effFiring,
      rightFiring: this.guns.right.effFiring,
      bubbles: this.sim.activeCount,
      tracking: this.tracking,
      firedOnce: this.firedOnce,
    };
    const key = `${+s.camera}${+s.left}${+s.right}${+s.leftFiring}${+s.rightFiring}|${s.bubbles}|${s.tracking}|${+s.firedOnce}`;
    if (key !== this.prevKey) {
      this.prevKey = key;
      this.o.onStatus(s);
    }
  }
}

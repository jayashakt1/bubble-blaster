import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

// Fetched by the browser at runtime. Override with VITE_* env vars to self-host
// (see README) if you need the app to work without these CDNs.
const WASM_BASE: string =
  (import.meta.env.VITE_MEDIAPIPE_WASM_URL as string | undefined) ||
  'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
const MODEL_URL: string =
  (import.meta.env.VITE_HAND_MODEL_URL as string | undefined) ||
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

export interface RawHand {
  /** MediaPipe handedness label for the raw (un-mirrored) frame. */
  label: string;
  landmarks: ReadonlyArray<{ x: number; y: number; z: number }>;
}

interface Category {
  categoryName: string;
}

export class HandTrackingService {
  private landmarker: HandLandmarker | null = null;
  private lastTs = 0;

  get ready(): boolean {
    return this.landmarker !== null;
  }

  async init(): Promise<void> {
    if (this.landmarker) return;
    const fileset = await FilesetResolver.forVisionTasks(WASM_BASE);
    const make = (delegate: 'GPU' | 'CPU') =>
      HandLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL_URL, delegate },
        runningMode: 'VIDEO',
        numHands: 2,
        minHandDetectionConfidence: 0.55,
        minHandPresenceConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });
    try {
      this.landmarker = await make('GPU');
    } catch {
      this.landmarker = await make('CPU');
    }
  }

  detect(video: HTMLVideoElement, nowMs: number): RawHand[] | null {
    if (!this.landmarker) return null;
    const ts = Math.max(Math.round(nowMs), this.lastTs + 1);
    this.lastTs = ts;
    const res = this.landmarker.detectForVideo(video, ts) as unknown as {
      landmarks: RawHand['landmarks'][];
      handedness?: Category[][];
      handednesses?: Category[][];
    };
    const handed = res.handedness ?? res.handednesses ?? [];
    const out: RawHand[] = [];
    for (let i = 0; i < res.landmarks.length; i++) {
      out.push({ label: handed[i]?.[0]?.categoryName ?? 'Right', landmarks: res.landmarks[i] });
    }
    return out;
  }

  dispose() {
    try {
      this.landmarker?.close();
    } catch {
      /* ignore */
    }
    this.landmarker = null;
  }
}

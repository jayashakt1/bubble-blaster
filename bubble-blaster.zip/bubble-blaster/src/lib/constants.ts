// Gun artwork is drawn pointing right (+x) in a 340x230 box.
export const GUN_W = 340;
export const GUN_H = 230;
/** Point of the gun that is pinned to the palm (centre of the grip). */
export const GUN_PIVOT = { x: 116, y: 162 };
/** Tip of the bubble nozzle, in gun-local coordinates. */
export const GUN_MUZZLE = { x: 331, y: 78 };

export const FILM_VARIANTS = 6;
export const HL_VARIANTS = 4;

/** Pastel soap-film palette as "r,g,b" strings. */
export const PALETTE_RGB = [
  '255,179,209', // rose
  '217,194,255', // lavender
  '184,241,255', // pale cyan
  '166,227,255', // aqua
  '255,243,176', // lemon
  '255,255,255', // pearl
  '200,255,230', // mint
  '201,178,255', // violet
];

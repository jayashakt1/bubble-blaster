/**
 * Trigger gesture = pinch (thumb tip touching index tip).
 * It is large, easy for MediaPipe to see, and does not change the aim direction
 * (aim comes from the wrist -> knuckle line). Hysteresis + short debounce avoid flicker.
 */
export class TriggerState {
  active = false;
  private onMs = 0;
  private offMs = 0;

  constructor(
    private engage = 0.3,
    private release = 0.48,
    private engageMs = 45,
    private releaseMs = 90,
  ) {}

  update(pinch: number, dtMs: number): boolean {
    if (!this.active) {
      if (pinch < this.engage) {
        this.onMs += dtMs;
        if (this.onMs >= this.engageMs) {
          this.active = true;
          this.onMs = 0;
          this.offMs = 0;
        }
      } else {
        this.onMs = 0;
      }
    } else if (pinch > this.release) {
      this.offMs += dtMs;
      if (this.offMs >= this.releaseMs) {
        this.active = false;
        this.offMs = 0;
        this.onMs = 0;
      }
    } else {
      this.offMs = 0;
    }
    return this.active;
  }

  reset() {
    this.active = false;
    this.onMs = 0;
    this.offMs = 0;
  }
}

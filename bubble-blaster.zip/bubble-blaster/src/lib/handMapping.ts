import type { Vec } from './types';

/**
 * Maps normalised video coordinates (0..1, un-mirrored camera frame) to stage pixels.
 * The <video> uses `object-fit: cover` and is mirrored with CSS, so the same
 * cover-crop + horizontal flip is applied here. That keeps every overlay aligned
 * with what the user sees on screen.
 */
export interface ViewMap {
  map(nx: number, ny: number, out: Vec): Vec;
}

export function makeViewMap(
  stageW: number,
  stageH: number,
  videoW: number,
  videoH: number,
  mirror = true,
): ViewMap {
  const s = Math.max(stageW / videoW, stageH / videoH);
  const dw = videoW * s;
  const dh = videoH * s;
  const ox = (stageW - dw) / 2;
  const oy = (stageH - dh) / 2;
  return {
    map(nx, ny, out) {
      let x = ox + nx * dw;
      if (mirror) x = stageW - x;
      out.x = x;
      out.y = oy + ny * dh;
      return out;
    },
  };
}

export interface HandPose {
  /** Stable palm anchor in stage pixels. */
  palm: Vec;
  indexTip: Vec;
  /** Aim direction in radians (screen space, 0 = pointing right). */
  angle: number;
  /** Approximate palm length in pixels. */
  size: number;
  /** Thumb-tip to index-tip distance relative to palm size (small = pinch). */
  pinch: number;
}

export function createPose(): HandPose {
  return { palm: { x: 0, y: 0 }, indexTip: { x: 0, y: 0 }, angle: 0, size: 100, pinch: 1 };
}

export function createPoints(): Vec[] {
  return Array.from({ length: 21 }, () => ({ x: 0, y: 0 }));
}

function dist(a: Vec, b: Vec): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/**
 * Converts 21 MediaPipe landmarks to a gun pose. `pts` is scratch storage that is
 * reused every call so nothing is allocated in the hot path.
 */
export function computeHandPose(
  lm: ReadonlyArray<{ x: number; y: number }>,
  view: ViewMap,
  pts: Vec[],
  out: HandPose,
): HandPose {
  for (let i = 0; i < 21; i++) view.map(lm[i].x, lm[i].y, pts[i]);
  const wrist = pts[0];
  const p4 = pts[4];
  const p5 = pts[5];
  const p8 = pts[8];
  const p9 = pts[9];
  const p13 = pts[13];
  const p17 = pts[17];

  out.palm.x = (wrist.x + p5.x + p9.x + p13.x + p17.x) / 5;
  out.palm.y = (wrist.y + p5.y + p9.y + p13.y + p17.y) / 5;

  out.size = Math.max(dist(wrist, p9), dist(p5, p17) * 1.2, 24);

  // Orientation: wrist -> middle knuckle, nudged by the index finger direction.
  const ax = p9.x - wrist.x + 0.6 * (p8.x - p5.x);
  const ay = p9.y - wrist.y + 0.6 * (p8.y - p5.y);
  if (Math.hypot(ax, ay) > 1e-3) out.angle = Math.atan2(ay, ax);

  out.pinch = dist(p4, p8) / out.size;
  out.indexTip.x = p8.x;
  out.indexTip.y = p8.y;
  return out;
}

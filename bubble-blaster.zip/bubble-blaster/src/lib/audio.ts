/**
 * Tiny synthesized sound effects (no audio files). The AudioContext is only created
 * after a user gesture via unlock().
 */
export class AudioFX {
  enabled = true;
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private lastFire = 0;
  private lastPop = 0;

  unlock() {
    try {
      if (!this.ctx) {
        const AC =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.5;
        this.master.connect(this.ctx.destination);
        const len = Math.floor(this.ctx.sampleRate * 0.08);
        this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const d = this.noise.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      }
      if (this.ctx.state === 'suspended') void this.ctx.resume();
    } catch {
      /* audio is optional */
    }
  }

  private ready(): boolean {
    return this.enabled && !!this.ctx && !!this.master && this.ctx.state === 'running';
  }

  private blip(freq0: number, freq1: number, dur: number, gain: number, type: OscillatorType, delay = 0) {
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq0, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, freq1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(this.master!);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  pop(size = 30) {
    if (!this.ready()) return;
    const now = performance.now();
    if (now - this.lastPop < 25) return;
    this.lastPop = now;
    const base = 900 - Math.min(500, size * 6) + Math.random() * 300;
    this.blip(base, base * 0.35, 0.09, 0.06, 'sine');
    const ctx = this.ctx!;
    if (this.noise) {
      const src = ctx.createBufferSource();
      src.buffer = this.noise;
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.value = 3500;
      const g = ctx.createGain();
      g.gain.value = 0.03;
      src.connect(hp).connect(g).connect(this.master!);
      src.start();
    }
  }

  fire() {
    if (!this.ready()) return;
    const now = performance.now();
    if (now - this.lastFire < 110) return;
    this.lastFire = now;
    this.blip(520, 880, 0.06, 0.016, 'triangle');
  }

  sparkle() {
    if (!this.ready()) return;
    [1318.5, 1568, 1976, 2349].forEach((f, i) => this.blip(f, f * 1.01, 0.28, 0.03, 'sine', i * 0.07));
  }

  dispose() {
    try {
      void this.ctx?.close();
    } catch {
      /* ignore */
    }
    this.ctx = null;
    this.master = null;
  }
}

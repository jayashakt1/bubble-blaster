import type { StatusSnapshot } from '../lib/types';

function Pill({ on, label, short, value }: { on: boolean; label: string; short: string; value: string }) {
  return (
    <div className={`pill ${on ? 'on' : 'off'}`}>
      <span className="dot" />
      <span className="pill-label">{label}:</span>
      <span className="pill-short">{short}:</span>
      <b>{value}</b>
    </div>
  );
}

export function StatusIndicators({ status }: { status: StatusSnapshot }) {
  const t = status.tracking;
  const hand = (found: boolean) =>
    t === 'error' ? 'UNAVAILABLE' : t !== 'ready' ? 'LOADING' : found ? 'DETECTED' : 'SEARCHING';
  return (
    <div className="status glass" role="status" aria-label="Tracking status">
      <Pill on={status.camera} label="Camera" short="Cam" value={status.camera ? 'ON' : 'OFF'} />
      <Pill on={status.left} label="Left hand" short="L" value={hand(status.left)} />
      <Pill on={status.right} label="Right hand" short="R" value={hand(status.right)} />
    </div>
  );
}

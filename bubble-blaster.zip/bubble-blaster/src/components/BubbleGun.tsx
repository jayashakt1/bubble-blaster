import { forwardRef } from 'react';
import { GUN_H, GUN_MUZZLE, GUN_PIVOT, GUN_W } from '../lib/constants';
import type { Side } from '../lib/types';

/**
 * Two original toy bubble blasters (not weapons): each has a bubble-solution dome,
 * a nozzle ring and sticker decals. Artwork points right (+x); the engine positions,
 * rotates and scales the wrapper, and flips it vertically when aiming leftwards.
 */

function Heart({ x, y, s = 1, fill = '#fff' }: { x: number; y: number; s?: number; fill?: string }) {
  return (
    <path
      transform={`translate(${x} ${y}) scale(${s})`}
      d="M0 5 C-11 -4 -5 -12 0 -6 C5 -12 11 -4 0 5Z"
      fill={fill}
    />
  );
}

function Strawberry({ x, y, s = 1 }: { x: number; y: number; s?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path
        d="M0 -10 C11 -15 19 -3 13 9 C9 17 3 21 0 23 C-3 21 -9 17 -13 9 C-19 -3 -11 -15 0 -10Z"
        fill="#F06292"
        stroke="#E0457B"
        strokeWidth="1.5"
      />
      <path d="M-9 -11 L-4 -19 L0 -13 L4 -19 L9 -11 L0 -8Z" fill="#8BD3A8" stroke="#5DB68A" strokeWidth="1.2" />
      {[[-5, 2], [4, 0], [-1, 8], [6, 9], [-7, 11], [1, 15]].map(([sx, sy], i) => (
        <ellipse key={i} cx={sx} cy={sy} rx="1.2" ry="1.8" fill="#FFF9F4" />
      ))}
      <path d="M-8 -3 C-8 -7 -5 -9 -3 -9" stroke="#fff" strokeWidth="1.8" fill="none" strokeLinecap="round" opacity=".8" />
    </g>
  );
}

function Flower({ x, y, s = 1 }: { x: number; y: number; s?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse
          key={a}
          cx="0"
          cy="-9"
          rx="6.5"
          ry="8.5"
          transform={`rotate(${a})`}
          fill="#FFF9F4"
          stroke="#F8BFD4"
          strokeWidth="1.2"
        />
      ))}
      <circle r="5" fill="#FFE6A8" stroke="#F4B860" strokeWidth="1" />
    </g>
  );
}

function Pearls({ y, from, to, step, id }: { y: number; from: number; to: number; step: number; id: string }) {
  const xs: number[] = [];
  for (let x = from; x <= to; x += step) xs.push(x);
  return (
    <g>
      {xs.map((x) => (
        <circle key={x} cx={x} cy={y} r="3.6" fill={`url(#${id}-pearl)`} stroke="#E8DDF8" strokeWidth=".6" />
      ))}
    </g>
  );
}

function Effects({ glowColor }: { glowColor: string }) {
  return (
    <>
      <circle className="muzzle-glow" cx={GUN_MUZZLE.x} cy={GUN_MUZZLE.y} r="22" fill={glowColor} />
      <circle
        className="ping"
        cx={GUN_PIVOT.x}
        cy={GUN_PIVOT.y}
        r="26"
        fill="none"
        stroke="#fff"
        strokeWidth="4"
      />
    </>
  );
}

function Common({ id, c1, c2, stroke, gripA, gripB }: {
  id: string; c1: string; c2: string; stroke: string; gripA: string; gripB: string;
}) {
  return (
    <defs>
      <linearGradient id={`${id}-body`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={c1} />
        <stop offset=".6" stopColor={c2} />
        <stop offset="1" stopColor={stroke} stopOpacity=".55" />
      </linearGradient>
      <linearGradient id={`${id}-grip`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={gripA} />
        <stop offset="1" stopColor={gripB} />
      </linearGradient>
      <linearGradient id={`${id}-dome`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#fff" stopOpacity=".75" />
        <stop offset="1" stopColor="#E8DDF8" stopOpacity=".45" />
      </linearGradient>
      <radialGradient id={`${id}-pearl`} cx=".35" cy=".3" r=".8">
        <stop offset="0" stopColor="#fff" />
        <stop offset=".6" stopColor="#FFF1F6" />
        <stop offset="1" stopColor="#E8DDF8" />
      </radialGradient>
      <radialGradient id={`${id}-bub`} cx=".35" cy=".3" r=".8">
        <stop offset="0" stopColor="#fff" stopOpacity=".9" />
        <stop offset=".7" stopColor="#D9C2FF" stopOpacity=".25" />
        <stop offset="1" stopColor="#B8F1FF" stopOpacity=".6" />
      </radialGradient>
    </defs>
  );
}

function Dome({ id }: { id: string }) {
  return (
    <g>
      <path d="M118 42 Q118 6 164 6 Q210 6 210 42 Z" fill={`url(#${id}-dome)`} stroke="#fff" strokeWidth="2.5" />
      <circle cx="146" cy="30" r="9" fill={`url(#${id}-bub)`} stroke="#fff" strokeWidth="1" />
      <circle cx="170" cy="22" r="6" fill={`url(#${id}-bub)`} stroke="#fff" strokeWidth="1" />
      <circle cx="188" cy="32" r="8" fill={`url(#${id}-bub)`} stroke="#fff" strokeWidth="1" />
      <path d="M128 36 Q130 16 150 12" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" opacity=".85" />
    </g>
  );
}

function GripAndGuard({ id, stroke, guard, trigger }: { id: string; stroke: string; guard: string; trigger: string }) {
  return (
    <g>
      <path
        d="M80 112 L152 112 L141 205 Q139 222 121 222 L98 222 Q79 222 81 203 Z"
        fill={`url(#${id}-grip)`}
        stroke={stroke}
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
      {[[104, 140], [118, 140], [132, 140], [102, 160], [116, 160], [130, 160], [101, 180], [115, 180], [129, 180]].map(
        ([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r="2.6" fill="#fff" opacity=".55" />
        ),
      )}
      <path d="M158 116 Q161 168 198 168 Q224 168 224 146 L224 116" fill="none" stroke={guard} strokeWidth="9" strokeLinecap="round" />
      <path d="M158 116 Q161 168 198 168" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity=".6" transform="translate(-1 -2)" />
      <g className="trigger">
        <path d="M178 116 Q186 150 172 152 Q160 150 166 116 Z" fill={trigger} stroke="#fff" strokeWidth="1.5" />
      </g>
    </g>
  );
}

function Nozzle({ collar, stroke }: { collar: string; stroke: string }) {
  return (
    <g>
      <rect x="290" y="52" width="14" height="52" rx="6" fill={collar} stroke={stroke} strokeWidth="2.5" />
      <rect x="300" y="58" width="24" height="40" rx="12" fill="#FFF9F4" stroke="#F8BFD4" strokeWidth="2.5" />
      <ellipse cx="322" cy="78" rx="7" ry="17" fill="rgba(255,255,255,0.55)" stroke={stroke} strokeWidth="3" />
    </g>
  );
}

function StrawberryGun() {
  const id = 'sg';
  return (
    <svg className="gun-svg" viewBox={`0 0 ${GUN_W} ${GUN_H}`} width={GUN_W} height={GUN_H}>
      <Common id={id} c1="#FFEAF2" c2="#FFD6E7" stroke="#F48FB1" gripA="#FFD6E7" gripB="#F4A9C6" />
      <GripAndGuard id={id} stroke="#F48FB1" guard="#F8BFD4" trigger="#F48FB1" />
      <Dome id={id} />
      <rect x="50" y="38" width="246" height="80" rx="30" fill={`url(#${id}-body)`} stroke="#F48FB1" strokeWidth="3" />
      <rect x="88" y="56" width="150" height="44" rx="20" fill="#FFF9F4" stroke="#F8BFD4" strokeWidth="2" />
      <Strawberry x={125} y={76} s={0.95} />
      <Heart x={158} y={76} s={0.9} fill="#F8BFD4" />
      <Strawberry x={191} y={78} s={0.72} />
      <Heart x={218} y={74} s={0.7} fill="#fff" />
      <Pearls y={109} from={96} to={252} step={18} id={id} />
      <Nozzle collar="#F8BFD4" stroke="#F48FB1" />
      <path d="M66 50 Q76 43 150 43 L248 43" stroke="#fff" strokeWidth="5" fill="none" strokeLinecap="round" opacity=".6" />
      {/* little bow at the back of the grip */}
      <g transform="translate(68 120)">
        <path d="M0 0 C-18 -14 -22 12 0 0Z" fill="#FFF9F4" stroke="#F48FB1" strokeWidth="1.5" />
        <path d="M0 0 C16 -14 20 12 0 0Z" fill="#FFF9F4" stroke="#F48FB1" strokeWidth="1.5" />
        <circle r="4" fill="#F48FB1" />
      </g>
      <Effects glowColor="rgba(255,214,231,0.75)" />
    </svg>
  );
}

function PrincessGun() {
  const id = 'pg';
  return (
    <svg className="gun-svg" viewBox={`0 0 ${GUN_W} ${GUN_H}`} width={GUN_W} height={GUN_H}>
      <Common id={id} c1="#FF9CC2" c2="#F57BAB" stroke="#E0558F" gripA="#F8BFD4" gripB="#F06FA4" />
      <GripAndGuard id={id} stroke="#E0558F" guard="#F8BFD4" trigger="#FFF9F4" />
      <Dome id={id} />
      {/* tiny bow on top of the dome */}
      <g transform="translate(164 6)">
        <path d="M0 0 C-14 -12 -18 8 0 0Z" fill="#F8BFD4" stroke="#E0558F" strokeWidth="1.5" />
        <path d="M0 0 C14 -12 18 8 0 0Z" fill="#F8BFD4" stroke="#E0558F" strokeWidth="1.5" />
        <circle r="3.5" fill="#E0558F" />
      </g>
      <rect x="50" y="38" width="246" height="80" rx="30" fill={`url(#${id}-body)`} stroke="#E0558F" strokeWidth="3" />
      <rect x="84" y="56" width="132" height="44" rx="20" fill="#FFF9F4" stroke="#F8BFD4" strokeWidth="2" />
      <Flower x={116} y={79} s={0.95} />
      <Heart x={148} y={78} s={0.8} fill="#F8BFD4" />
      <Flower x={178} y={79} s={0.72} />
      <Heart x={203} y={77} s={0.65} fill="#fff" />
      {/* pearl medallion */}
      <g transform="translate(252 78)">
        <circle r="23" fill="#F8BFD4" stroke="#fff" strokeWidth="2.5" />
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return (
            <circle key={i} cx={Math.cos(a) * 16.5} cy={Math.sin(a) * 16.5} r="2.6" fill={`url(#${id}-pearl)`} stroke="#E8DDF8" strokeWidth=".5" />
          );
        })}
        <Heart x={0} y={1} s={1.15} fill="#fff" />
      </g>
      <Pearls y={109} from={96} to={216} step={18} id={id} />
      <Nozzle collar="#F8BFD4" stroke="#E0558F" />
      <path d="M66 50 Q76 43 150 43 L230 43" stroke="#fff" strokeWidth="5" fill="none" strokeLinecap="round" opacity=".55" />
      <Effects glowColor="rgba(255,182,213,0.8)" />
    </svg>
  );
}

interface Props {
  side: Side;
}

/** The engine writes transform/opacity/visibility directly on this element every frame. */
export const BubbleGun = forwardRef<HTMLDivElement, Props>(function BubbleGun({ side }, ref) {
  return (
    <div
      ref={ref}
      className={`gun gun-${side}`}
      data-firing="0"
      aria-hidden="true"
      style={{ width: GUN_W, height: GUN_H, visibility: 'hidden', opacity: 0 }}
    >
      {side === 'left' ? <StrawberryGun /> : <PrincessGun />}
    </div>
  );
});

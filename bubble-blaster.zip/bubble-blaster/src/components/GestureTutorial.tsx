interface Props {
  handsSeen: boolean;
  fired: boolean;
  onDismiss: () => void;
}

export function GestureTutorial({ handsSeen, fired, onDismiss }: Props) {
  const steps: { n: number; text: string; done: boolean }[] = [
    { n: 1, text: 'Show both hands to the camera.', done: handsSeen },
    { n: 2, text: 'Move your hands to aim your bubble blasters.', done: handsSeen },
    { n: 3, text: 'Make the trigger gesture (pinch thumb + index finger) to release bubbles.', done: fired },
    { n: 4, text: 'Watch your room fill with rainbow bubbles!', done: fired },
  ];
  return (
    <aside className="tutorial glass-soft" aria-label="How to play">
      <button className="tut-x" onClick={onDismiss} aria-label="Dismiss tutorial">
        ×
      </button>
      <p className="script small">how to play ♡</p>
      <ol>
        {steps.map((s) => (
          <li key={s.n} className={s.done ? 'done' : ''}>
            <b>STEP {s.n}:</b> {s.text}
          </li>
        ))}
      </ol>
      <button className="tut-ok" onClick={onDismiss}>
        got it ♡
      </button>
    </aside>
  );
}

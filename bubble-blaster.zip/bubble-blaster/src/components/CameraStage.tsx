import { useCallback, useEffect, useRef, useState } from 'react';
import type { AudioFX } from '../lib/audio';
import { GameEngine } from '../lib/GameEngine';
import { GameError, INITIAL_STATUS, StatusSnapshot } from '../lib/types';
import { BubbleGun } from './BubbleGun';
import { Bow, Decor } from './Decor';
import { GameControls } from './GameControls';
import { GestureTutorial } from './GestureTutorial';
import { StatusIndicators } from './StatusIndicators';

type Phase = 'camera' | 'model' | 'ready' | 'cameraError' | 'modelError';

interface Props {
  audio: AudioFX;
  onExit: () => void;
}

export function CameraStage({ audio, onExit }: Props) {
  const stageRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [attempt, setAttempt] = useState(0);
  const [phase, setPhase] = useState<Phase>('camera');
  const [error, setError] = useState('');
  const [status, setStatus] = useState<StatusSnapshot>(INITIAL_STATUS);
  const [paused, setPaused] = useState(false);
  const [shower, setShower] = useState(false);
  const [sound, setSound] = useState(true);
  const [tutorial, setTutorial] = useState(true);
  const [handsSeen, setHandsSeen] = useState(false);

  // One engine per mount/attempt. Cleanup stops the camera, tracker and animation loop.
  useEffect(() => {
    let alive = true;
    const engine = new GameEngine({
      stage: stageRef.current!,
      video: videoRef.current!,
      canvas: canvasRef.current!,
      leftGun: leftRef.current!,
      rightGun: rightRef.current!,
      audio,
      onStatus: (s) => alive && setStatus(s),
    });
    engineRef.current = engine;
    setPhase('camera');
    setError('');

    (async () => {
      try {
        await engine.startCamera();
      } catch (e) {
        if (!alive || (e instanceof GameError && e.cancelled)) return;
        setError(e instanceof Error ? e.message : 'The camera could not be started.');
        setPhase('cameraError');
        return;
      }
      if (!alive) return;
      engine.startLoop();
      setPhase('model');
      try {
        await engine.initTracker();
        if (alive) setPhase('ready');
      } catch (e) {
        if (!alive || (e instanceof GameError && e.cancelled)) return;
        setError(e instanceof Error ? e.message : 'Hand tracking could not start.');
        setPhase('modelError');
      }
    })();

    return () => {
      alive = false;
      engine.dispose();
      engineRef.current = null;
    };
  }, [attempt, audio]);

  // Keep the engine in sync with UI state (also after a retry creates a new engine).
  useEffect(() => engineRef.current?.setPaused(paused), [paused, attempt]);
  useEffect(() => engineRef.current?.setShower(shower), [shower, attempt]);
  useEffect(() => {
    audio.enabled = sound;
  }, [sound, audio]);

  // Hand tracking can fail later (e.g. GPU context lost) — be honest about it.
  useEffect(() => {
    if (phase === 'ready' && status.tracking === 'error') {
      setError('Hand tracking stopped working. Please try again ♡');
      setPhase('modelError');
    }
  }, [phase, status.tracking]);

  useEffect(() => {
    if (status.left || status.right) setHandsSeen(true);
  }, [status.left, status.right]);

  // Debug helper: "H" swaps which hand drives which gun if a browser reports them reversed.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'h' && !e.metaKey && !e.ctrlKey) engineRef.current?.swapHands();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const retryModel = useCallback(async () => {
    const engine = engineRef.current;
    if (!engine) return;
    setError('');
    setPhase('model');
    try {
      await engine.initTracker();
      // Clear the stale 'error' status so the watcher above does not fire again.
      setStatus((s) => ({ ...s, tracking: 'ready' }));
      setPhase('ready');
    } catch (e) {
      if (e instanceof GameError && e.cancelled) return;
      setError(e instanceof Error ? e.message : 'Hand tracking could not start.');
      setPhase('modelError');
    }
  }, []);

  const toggleShower = () => {
    setShower((v) => {
      if (!v) audio.sparkle();
      return !v;
    });
  };

  const showTutorial = tutorial && phase === 'ready';
  const noHands = phase === 'ready' && !status.left && !status.right;

  return (
    <div className="stage" ref={stageRef}>
      {/* Layer 1: live, mirrored webcam */}
      <video ref={videoRef} className="video" playsInline muted autoPlay />
      {/* Layer 3: bubble simulation */}
      <canvas ref={canvasRef} className="bubbles" aria-label="Floating bubbles. Tap a bubble to pop it." />
      {/* Layer 4: the two blasters */}
      <BubbleGun side="left" ref={leftRef} />
      <BubbleGun side="right" ref={rightRef} />
      {/* Layer 5: margin decorations */}
      <Decor />

      {/* Layer 6: interface */}
      <header className="title glass-soft">
        <Bow className="bow bow-l" size={24} />
        <Bow className="bow bow-r" size={24} />
        <h1>୨୧ BUBBLE BLASTER ୨୧</h1>
        <p className="script">blow a little magic into your world ♡</p>
      </header>

      <StatusIndicators status={status} />

      <div className="counter glass" aria-live="polite">
        ♡ Bubbles: <b>{String(status.bubbles).padStart(3, '0')}</b>
      </div>

      {phase === 'camera' && <div className="toast glass">asking your camera nicely… ♡</div>}
      {phase === 'model' && <div className="toast glass">waking up the bubble magic… ✧</div>}
      {noHands && !paused && <div className="toast glass">show me your hands ♡ pinch to blow bubbles</div>}
      {paused && phase === 'ready' && <div className="toast glass">paused ✧ press Start to blow bubbles again</div>}

      {showTutorial && (
        <GestureTutorial handsSeen={handsSeen} fired={status.firedOnce} onDismiss={() => setTutorial(false)} />
      )}
      {!tutorial && phase === 'ready' && (
        <button className="help glass" onClick={() => setTutorial(true)} aria-label="Show how to play">
          ✧ how to play
        </button>
      )}

      {(phase === 'cameraError' || phase === 'modelError') && (
        <div className="error-wrap">
          <div className="error-card glass-soft" role="alert">
            <p className="script">oh no… ♡</p>
            <p>{error}</p>
            <div className="error-actions">
              {phase === 'cameraError' ? (
                <button className="ctl" onClick={() => setAttempt((a) => a + 1)}>
                  Try again
                </button>
              ) : (
                <button className="ctl" onClick={retryModel}>
                  Try again
                </button>
              )}
              <button className="ctl" onClick={onExit}>
                Back to start
              </button>
            </div>
          </div>
        </div>
      )}

      <GameControls
        paused={paused}
        shower={shower}
        sound={sound}
        onTogglePause={() => setPaused((p) => !p)}
        onToggleShower={toggleShower}
        onClear={() => engineRef.current?.clear()}
        onToggleSound={() => setSound((s) => !s)}
        onExit={onExit}
      />
    </div>
  );
}

/** Small decorative pieces. They live in the margins and never take pointer events. */

export function Bow({ className = '', size = 28 }: { className?: string; size?: number }) {
  return (
    <svg className={className} width={size} height={size * 0.7} viewBox="0 0 40 28" aria-hidden="true">
      <path d="M20 14 C10 0 0 2 2 14 C0 26 10 28 20 14Z" fill="#F8BFD4" stroke="#F48FB1" strokeWidth="1.5" />
      <path d="M20 14 C30 0 40 2 38 14 C40 26 30 28 20 14Z" fill="#F8BFD4" stroke="#F48FB1" strokeWidth="1.5" />
      <path d="M8 9 C11 8 13 10 14 12" stroke="#fff" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity=".8" />
      <circle cx="20" cy="14" r="4" fill="#F48FB1" stroke="#fff" strokeWidth="1" />
    </svg>
  );
}

const GLYPHS: { g: string; side: 'l' | 'r'; top: number; delay: number; size: number }[] = [
  { g: '♡', side: 'l', top: 24, delay: 0, size: 18 },
  { g: '✧', side: 'l', top: 40, delay: 1.4, size: 16 },
  { g: '⋆', side: 'l', top: 58, delay: 2.6, size: 18 },
  { g: '♡', side: 'r', top: 28, delay: 0.8, size: 16 },
  { g: '✧', side: 'r', top: 46, delay: 2, size: 18 },
  { g: '⋆', side: 'r', top: 62, delay: 3.2, size: 16 },
];

export function Decor() {
  return (
    <div className="decor" aria-hidden="true">
      {GLYPHS.map((d, i) => (
        <span
          key={i}
          className={`dec dec-${d.side}`}
          style={{ top: `${d.top}%`, animationDelay: `${d.delay}s`, fontSize: d.size }}
        >
          {d.g}
        </span>
      ))}
    </div>
  );
}

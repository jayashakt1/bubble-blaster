import { Bow } from './Decor';

const BUBBLES = [
  { l: 8, s: 70, d: 0, t: 14 },
  { l: 20, s: 38, d: 3, t: 11 },
  { l: 33, s: 100, d: 6, t: 18 },
  { l: 52, s: 46, d: 1.5, t: 12 },
  { l: 66, s: 84, d: 4, t: 16 },
  { l: 78, s: 34, d: 7, t: 10 },
  { l: 90, s: 62, d: 2, t: 15 },
];

export function WelcomeScreen({ onStart }: { onStart: () => void }) {
  return (
    <main className="welcome">
      <div className="welcome-bubbles" aria-hidden="true">
        {BUBBLES.map((b, i) => (
          <span
            key={i}
            className="fbub"
            style={{ left: `${b.l}%`, width: b.s, height: b.s, animationDelay: `${b.d}s`, animationDuration: `${b.t}s` }}
          />
        ))}
      </div>

      <section className="welcome-panel glass-soft">
        <Bow className="bow bow-tl" size={38} />
        <Bow className="bow bow-tr" size={38} />
        <p className="script">୨୧ bubble blaster ୨୧</p>
        <h1>
          WELCOME TO YOUR LITTLE
          <br />
          BUBBLE WORLD ♡
        </h1>
        <p className="tagline">Two hands, two magical blasters, and a million tiny bubbles.</p>

        <button className="cta" onClick={onStart}>
          <span className="cta-kicker">♡ ENTER THE BUBBLE UNIVERSE ♡</span>
          <span className="cta-main">START PLAYING ୨୧</span>
        </button>

        <p className="note">
          Camera permission is needed for hand tracking. Your camera feed is used locally in your browser and is not
          uploaded by this experience.
        </p>
        <p className="sparkles" aria-hidden="true">
          ✧ ⋆ ♡ ⋆ ✧
        </p>
      </section>
    </main>
  );
}

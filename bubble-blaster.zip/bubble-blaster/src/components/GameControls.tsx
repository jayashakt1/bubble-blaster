interface Props {
  paused: boolean;
  shower: boolean;
  sound: boolean;
  onTogglePause: () => void;
  onToggleShower: () => void;
  onClear: () => void;
  onToggleSound: () => void;
  onExit: () => void;
}

export function GameControls(p: Props) {
  return (
    <nav className="controls glass" aria-label="Game controls">
      <button className="ctl" onClick={p.onTogglePause} aria-pressed={p.paused}>
        <span className="ico">♡</span>
        {p.paused ? 'Start' : 'Pause'}
      </button>
      <button className="ctl" onClick={p.onToggleShower} aria-pressed={p.shower}>
        <span className="ico">✧</span>
        Bubble Shower
      </button>
      <button className="ctl" onClick={p.onClear}>
        <span className="ico">୨୧</span>
        Clear Bubbles
      </button>
      <button className="ctl" onClick={p.onToggleSound} aria-pressed={p.sound}>
        <span className="ico">♫</span>
        Sound {p.sound ? 'ON' : 'OFF'}
      </button>
      <button className="ctl" onClick={p.onExit}>
        <span className="ico">♡</span>
        Exit Camera
      </button>
    </nav>
  );
}

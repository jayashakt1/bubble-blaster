# Bubble Blaster ♡

A dreamy pink webcam game. Your live camera is the background; two toy bubble blasters follow your hands and blow iridescent soap bubbles when you pinch.

Stack: React + TypeScript + Vite, MediaPipe Tasks Vision (hand tracking), Canvas 2D (bubbles), SVG (blasters), Web Audio (synthesized sounds, no audio files).

## Run

```bash
npm install
npm run dev        # http://localhost:5173  (localhost counts as a secure context for the camera)
npm run build      # type-check + production build into dist/
```

Production must be served over **HTTPS** for webcam access.

## How to play

1. Press **START PLAYING** and allow the camera.
2. Show both hands. Left hand drives the Strawberry Milk Blaster, right hand drives the Bubblegum Princess Blaster.
3. Point where you want to aim (the blaster follows your wrist → knuckle direction).
4. **Pinch thumb + index finger** to blow bubbles; release to stop. Pinch with both hands for dual fire.
5. Click/tap a bubble to pop it. Your index fingertip also pops bubbles it touches (when that hand isn't firing).

**Bubble Shower** makes any detected hand's blaster fire continuously and more densely (no pinch needed). It never fires from a hand that isn't detected.

Press **H** if your browser reports hands reversed (swaps left/right).

## Project layout

```
src/
  App.tsx                      welcome <-> playing
  components/
    WelcomeScreen.tsx  CameraStage.tsx  BubbleGun.tsx (two SVG blasters)
    GameControls.tsx   StatusIndicators.tsx  GestureTutorial.tsx  Decor.tsx
  lib/
    GameEngine.ts              single rAF loop: camera, tracking, guns, firing, status, cleanup
    HandTrackingService.ts     MediaPipe HandLandmarker wrapper (2 hands, GPU -> CPU fallback)
    handMapping.ts             cover-crop + mirror mapping, palm anchor, aim angle, pinch ratio
    gestures.ts                pinch trigger with hysteresis + debounce
    bubbleSim.ts               bubble/particle physics, pooling, popping
    bubbleRender.ts            pre-rendered iridescent film + specular sprites, canvas drawing
    audio.ts                   synthesized pop / fire / sparkle sounds
```

## Network use & privacy

Camera frames never leave the browser. The only network requests are static assets: the MediaPipe WASM runtime (jsDelivr), the hand-landmarker model (Google storage) and Google Fonts. To self-host the first two, copy `node_modules/@mediapipe/tasks-vision/wasm/*` and `hand_landmarker.task` into `public/` and set in `.env`:

```
VITE_MEDIAPIPE_WASM_URL=/wasm
VITE_HAND_MODEL_URL=/hand_landmarker.task
```
